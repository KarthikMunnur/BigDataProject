public class ShoppingTrend {
    private String customerId;
    private double age;
    private String gender;
    private String itemPurchased;
    private String category;
    private double purchaseAmount;
    private String location;
    private String size;
    private String color;
    private String season;
    private int reviewRating;
    private String subscriptionStatus;
    private String shippingType;
    private String discountApplied;
    private String promoCodeUsed;
    private int previousPurchases;
    private String paymentMethod;
    private String preferredPaymentMethod;
    private String frequencyOfPurchases;

    // Constructors
    public ShoppingTrend() {
        // Default constructor
    }

    public ShoppingTrend(String customerId, double age, String gender, String itemPurchased, String category,
            double purchaseAmount, String location, String size, String color, String season,
            int reviewRating, String subscriptionStatus, String shippingType, String discountApplied,
            String promoCodeUsed, int previousPurchases, String paymentMethod,
            String preferredPaymentMethod, String frequencyOfPurchases) {
// constructor implementation
        this.customerId = customerId;
        this.age = age;
        this.gender = gender;
        this.itemPurchased = itemPurchased;
        this.category = category;
        this.purchaseAmount = purchaseAmount;
        this.location = location;
        this.size = size;
        this.color = color;
        this.season = season;
        this.reviewRating = reviewRating;
        this.subscriptionStatus = subscriptionStatus;
        this.shippingType = shippingType;
        this.discountApplied = discountApplied;
        this.promoCodeUsed = promoCodeUsed;
        this.previousPurchases = previousPurchases;
        this.paymentMethod = paymentMethod;
        this.preferredPaymentMethod = preferredPaymentMethod;
        this.frequencyOfPurchases = frequencyOfPurchases;
    }

    // Getters and setters for each attribute
    public String getCustomerId() {
        return customerId;
    }

    public void setCustomerId(String customerId) {
        this.customerId = customerId;
    }

    public double getAge() {
        return age;
    }

    public void setAge(double age) {
        this.age = age;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getItemPurchased() {
        return itemPurchased;
    }

    public void setItemPurchased(String itemPurchased) {
        this.itemPurchased = itemPurchased;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public double getPurchaseAmount() {
        return purchaseAmount;
    }

    public void setPurchaseAmount(double purchaseAmount) {
        this.purchaseAmount = purchaseAmount;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getSize() {
        return size;
    }

    public void setSize(String size) {
        this.size = size;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public String getSeason() {
        return season;
    }

    public void setSeason(String season) {
        this.season = season;
    }

    public int getReviewRating() {
        return reviewRating;
    }

    public void setReviewRating(int reviewRating) {
        this.reviewRating = reviewRating;
    }

    public String getSubscriptionStatus() {
        return subscriptionStatus;
    }

    public void setSubscriptionStatus(String subscriptionStatus) {
        this.subscriptionStatus = subscriptionStatus;
    }

    public String getShippingType() {
        return shippingType;
    }

    public void setShippingType(String shippingType) {
        this.shippingType = shippingType;
    }

    public String getDiscountApplied() {
        return discountApplied;
    }

    public void setDiscountApplied(String discountApplied) {
        this.discountApplied = discountApplied;
    }

    public String getPromoCodeUsed() {
        return promoCodeUsed;
    }

    public void setPromoCodeUsed(String promoCodeUsed) {
        this.promoCodeUsed = promoCodeUsed;
    }

    public int getPreviousPurchases() {
        return previousPurchases;
    }

    public void setPreviousPurchases(int previousPurchases) {
        this.previousPurchases = previousPurchases;
    }

    public String getPaymentMethod() {
        return paymentMethod;
    }

    public void setPaymentMethod(String paymentMethod) {
        this.paymentMethod = paymentMethod;
    }

    public String getPreferredPaymentMethod() {
        return preferredPaymentMethod;
    }

    public void setPreferredPaymentMethod(String preferredPaymentMethod) {
        this.preferredPaymentMethod = preferredPaymentMethod;
    }

    public String getFrequencyOfPurchases() {
        return frequencyOfPurchases;
    }

    public void setFrequencyOfPurchases(String frequencyOfPurchases) {
        this.frequencyOfPurchases = frequencyOfPurchases;
    }

    // Additional methods, if needed
}
