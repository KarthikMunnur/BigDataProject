import com.opencsv.CSVReader;


import java.io.FileReader;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class VisualizeSalesDistribution {
    public static void main(String[] args) {
        String csvFile = "shopping_trends.csv";

        ArrayList<ShoppingTrend> shoppingList = new ArrayList<>();

        try (CSVReader reader = new CSVReader(new FileReader(csvFile))) {
            List<String[]> rows = reader.readAll();
            boolean skipHeader = true;

            for (String[] row : rows) {
                if (skipHeader) {
                    skipHeader = false;
                    continue;
                    
                }

                ShoppingTrend shoppingTrend = new ShoppingTrend(
                        row[0], Integer.parseInt(row[1]), row[2], row[3], row[4],
                        Double.parseDouble(row[5]), row[6], row[7], row[8], row[9],
                        Integer.parseInt(row[10]), row[11], row[12], row[13],
                        csvFile, Integer.parseInt(row[14]), row[15], row[16], row[17]
                );

                shoppingList.add(shoppingTrend);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        Set<ShoppingTrend> uniqueShoppingSet = new HashSet<>(shoppingList);
        Set<ShoppingTrend> set = new HashSet<>(shoppingList);
        Stream<ShoppingTrend> shoppingStream = uniqueShoppingSet.stream();

        // Goal: Visualize the distribution of sales across different product categories
        System.out.println("************************************************************************************************");

        System.out.println("\nSEQUENTIAL EXECUTION FOR GOAL 1\n");

        long startTime = System.currentTimeMillis();

        // Count sales for each product category
     // Count sales for each product category
     // Count sales for each product category
        long countClothing = uniqueShoppingSet.stream().filter(obj -> obj.getCategory().equalsIgnoreCase("Clothing")).count();
        long countFootwear = uniqueShoppingSet.stream().filter(obj -> obj.getCategory().equalsIgnoreCase("Footwear")).count();
        long countOuterwear = uniqueShoppingSet.stream().filter(obj -> obj.getCategory().equalsIgnoreCase("Outerwear")).count();
        long countAccessories = uniqueShoppingSet.stream().filter(obj -> obj.getCategory().equalsIgnoreCase("Accessories")).count();


        long endTime = System.currentTimeMillis();

        System.out.println("sequential execution time: " + (endTime - startTime) + " milliseconds");
        
        startTime = System.currentTimeMillis();
        Map<String, Long> categoryDistributionParallel = set.parallelStream()
                .collect(Collectors.groupingByConcurrent(ShoppingTrend::getCategory, Collectors.counting()));
        endTime = System.currentTimeMillis();
        System.out.println();
        System.out.println("************************************************************************************************");

        System.out.println("\nPARALLEL EXECUTION FOR GOAL 1\n");
        System.out.println("Parallel execution time: " + (endTime - startTime) + " milliseconds");
        
        System.out.println("************************************************************************************************");

        
        System.out.println("\nSEQUENTIAL EXECUTION FOR GOAL 2\n");

        long startTime1 = System.currentTimeMillis();
        long countWinter = set.stream().filter(obj -> obj.getSeason().equalsIgnoreCase("Winter")).count();
        long countSpring = set.stream().filter(obj -> obj.getSeason().equalsIgnoreCase("Spring")).count();
        long countSummer = set.stream().filter(obj -> obj.getSeason().equalsIgnoreCase("Summer")).count();
        long countFall = set.stream().filter(obj -> obj.getSeason().equalsIgnoreCase("Fall")).count();
        long endTime1 = System.currentTimeMillis();

        System.out.println("sequential execution time : " + (endTime1 - startTime1) + " milliseconds");
        System.out.println();
        System.out.println("************************************************************************************************");
        System.out.println("\nPARALLEL EXECUTION FOR GOAL 2\n");

        startTime = System.currentTimeMillis();
        countWinter = set.parallelStream().filter(obj -> obj.getSeason().equalsIgnoreCase("Winter")).count();
        countSpring = set.parallelStream().filter(obj -> obj.getSeason().equalsIgnoreCase("Spring")).count();
        countSummer = set.parallelStream().filter(obj -> obj.getSeason().equalsIgnoreCase("Summer")).count();
        countFall = set.parallelStream().filter(obj -> obj.getSeason().equalsIgnoreCase("Fall")).count();
        endTime = System.currentTimeMillis();

        System.out.println("parallel execution time : " + (endTime - startTime) + " milliseconds");
       
        
    }
    }
